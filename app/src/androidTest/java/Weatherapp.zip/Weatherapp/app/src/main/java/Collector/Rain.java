package Collector;

public class Rain {
    private float perception;

}
