package Collector;

public class Wind {
    private float speed;
    private int degrees;

    public int getDegrees() {
        return degrees;
    }

    public float getSpeed() {
        return speed;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }

    public void setDegrees(int degrees) {
        this.degrees = degrees;
    }
}
