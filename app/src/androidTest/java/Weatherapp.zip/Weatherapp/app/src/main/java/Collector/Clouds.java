package Collector;

public class Clouds {
    public int getPerception() {
        return perception;
    }

    public void setPerception(int perception) {
        this.perception = perception;
    }

    private int perception;

}
