package Collector;

public class Weather {
    public Location location = new Location();
    public Rain rain = new Rain();

    public Wind wind = new Wind();
    public Condition cond = new Condition();
    public Clouds clouds = new Clouds();
    public String iconinfo;
    public String description;

}

